# Medical Appointment Management System

Medical clinic with one doctor, needs appointment management system, where clinic admin can review appointments by date or patient 

Also admin can check patient history on demand, add new appointment, cancel appointment with cancellation reason (No show, based on patient request, Physician apology)

# Functionalities Performed:

-	Admin can open home page which list all todays appointments 
-	Admin can add new appointment
-	Admin can cancel and and log the reason
-	Admin can filter appointments by date (future or history)
-	Admin can filter appointments by patient name (search field)
-	Admin can preview patient appointments history 

# Technologies Used:
1.	Spring Tool Suite
2.	Spring MVC
3.	Hibernate
4.	iText Pdf
5.	Email API
6.	Salt Encryption
7.	MySql Workebench 8.0 
